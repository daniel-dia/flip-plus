﻿function exitApp() {
    window.external.notify("exit");
}

function back() {
    
    FlipPlus.InvertCrossaGame.screenViewer.currentScreen.back();
}