﻿var items = {
    "hint": {price:   [2, 5, 10, 30, 50], },
    "solve": { price: [2, 5, 10, 30, 50], },
    "time": { price: [2, 5, 10, 30, 50], },
    "tap": { price: [2, 5, 10, 30, 50], },
    "skip": {price:[1]},
}
 