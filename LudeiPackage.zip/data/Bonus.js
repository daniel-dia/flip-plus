﻿//time in minutes
var bonusData = {
    "Bonus1": { id: "Bonus1", cost: 6, timeOut:  12  },
    "Bonus2": { id: "Bonus2", cost: 20, timeOut: 18  },
    "Bonus3": { id: "Bonus3", cost: 30, timeOut: 24  }
}