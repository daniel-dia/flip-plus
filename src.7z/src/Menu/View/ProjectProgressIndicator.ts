module FlipPlus.Menu.View {

    //View
    export class ProjectProgressIndicator extends PIXI.Container {

        private progressBar: PIXI.DisplayObject;

        constructor() {
            super();

            this.createObjects();

        }

        //create objects
        private createObjects() {
            var bg: PIXI.Shape = new PIXI.Shape();
            bg.graphics.beginFill("#FA0").rect(0, 0, 400, 150);
            this.addChild(bg);

            var pbarbg: PIXI.Shape = new PIXI.Shape();
            pbarbg.graphics.beginFill("#620").rect(50, 50, 300, 50);
            this.addChild(pbarbg);

            var pbar: PIXI.Shape = new PIXI.Shape();
            pbar.graphics.beginFill("#FF0").rect(50, 50, 300, 50);
            this.addChild(pbar);
            this.progressBar = pbar;

        }



        // update object based on its info
        public updateProjectInfo(progress: number) {
            if (progress > 1) progress = 1;
            if (progress < 0) progress = 0;

            if (progress == undefined) progress = 0;
            this.progressBar.scale.x = progress;

        }
    }
}
