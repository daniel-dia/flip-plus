/// <reference path="../../lib/easeljs.d.ts" />B
/// <reference path="../InvertCrossGame.ts" />  
/// <reference path="../GamePlay/Level.ts" /> 


/// <reference path="../../Gbase/ScreenState.ts" /> 

module InvertCross.Menu {

    export class TimeAttack extends InvertCross.ScreenState {

        constructor() {
            super();
        }
    }
}